# MASTER models to complete
- ClaSSE
- SIR + Migration/Visitor
- GeoSSE w/ competitive interactions

# other models
- treeducken
- siphy

# models using RevBayes for simulation
- FIG
- biome shift stuff
- network evolution

# simple models using various R scripts
- birth-death
- CTMC
- cont trait
- SSE
