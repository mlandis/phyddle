#!/usr/bin/env python
"""
__init__
===========
Initializes phyddle package and discovers all modules.

Authors:   Michael Landis, Ammon Thompson
Copyright: (c) 2023, Michael Landis
License:   MIT
"""