#!/usr/bin/env sh
cp scripts/__config_default.py tests/
pytest tests/
