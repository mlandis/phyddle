Build Sphinx documentation

```
make html
```

View Sphinx HTML page
```
open build/html/index.html
```
