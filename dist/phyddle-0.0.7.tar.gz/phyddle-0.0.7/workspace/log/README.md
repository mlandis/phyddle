# log

The logs directory contains various analysis metadata as log-files. These files may be useful for debugging analyses and/or reproducing results.
