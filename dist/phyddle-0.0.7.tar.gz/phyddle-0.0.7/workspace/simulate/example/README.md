Note, `raw_data/example` contains only 20 of 25,000 total replicates. Run `./code/run_simulate.sh --cfg config --proj example --start_idx 0 --end_idx 25000` to simulate the full dataset.
