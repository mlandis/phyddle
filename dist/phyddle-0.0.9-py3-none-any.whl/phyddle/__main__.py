#!/usr/bin/env python3
from phyddle.command_line import run

def main():
    run()

if __name__ == '__main__':
    main()
